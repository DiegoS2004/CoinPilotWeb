import { prisma } from "./prisma"
import type { User } from "@supabase/supabase-js"

export async function createOrUpdateUser(supabaseUser: User) {
  const userData = {
    id: supabaseUser.id,
    email: supabaseUser.email!,
    fullName: supabaseUser.user_metadata?.full_name || null,
  }

  return await prisma.user.upsert({
    where: { id: supabaseUser.id },
    update: {
      email: userData.email,
      fullName: userData.fullName,
    },
    create: userData,
  })
}

export async function deleteUser(userId: string) {
  return await prisma.user.delete({
    where: { id: userId },
  })
}
